import psycopg2


def get_ids_from_dwh():
    dwh_ids = {}

    # Credenciales de la base de datos
    DB_NAME = "digital_platform_dev"
    DB_USER = "dev_user"
    DB_PASSWORD = "Ls2GxM3e"
    DB_HOST = "dev-dp-data-analytics-data-warehouse.cxu5fxz68hh0.us-east-1.redshift.amazonaws.com"
    DB_PORT = "5439"

    try:
        # Conexión a la base de datos
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT
        )

        # Cursor para ejecutar comandos SQL
        cur = conn.cursor()

        # Ejecución del SELECT
        cur.execute("SELECT id FROM assessments.assessment_templates;")

        # Obtención de los resultados y conversión a un set
        dwh_ids = set(row[0] for row in cur.fetchall())

        # Impresión de la cantidad de registros
        print(f"La cantidad de registros es: {len(dwh_ids)}")

    except psycopg2.Error as e:
        print(f"Error al conectarse a la base de datos: {e}")

    finally:
        # Cierre del cursor y la conexión
        try:
            cur.close()
        except Exception as e:
            print(e)
        try:
            conn.close()
        except:
            pass
    return dwh_ids


def get_ids_from_rds():
    # Credenciales de la base de datos
    DB_NAME = "nombre_bd"
    DB_USER = "nombre_usuario"
    DB_PASSWORD = "contraseña"
    DB_HOST = "host_postgres"
    DB_PORT = "puerto"

    try:
        # Conexión a la base de datos
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT
        )

        # Cursor para ejecutar comandos SQL
        cur = conn.cursor()

        # Ejecución del SELECT
        cur.execute("SELECT id FROM prueba")

        # Obtención de los resultados y conversión a un set
        result_set = set(row[0] for row in cur.fetchall())

        # Cierre del cursor y la conexión
        cur.close()
        conn.close()

        # Retorno del resultado
        return result_set

    except psycopg2.Error as e:
        print(f"Error al conectarse a la base de datos: {e}")
        return set()


get_ids_from_dwh()

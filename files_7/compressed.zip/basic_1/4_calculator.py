"""Calculator"""

n1 = input("Type first number: ")
n2 = input("Type second number: ")

n1 = int(n1)
n2 = int(n2)

print(n1 + n2)

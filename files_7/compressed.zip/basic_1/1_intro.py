"""Python intro"""

print("Hello world!")
print("weta " * 7)

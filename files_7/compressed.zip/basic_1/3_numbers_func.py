import math

print(math.isnan(2.3))
# print(math.isnan("2.3"))

print(math.pow(2, 3))
print(math.sqrt(16))

"""For Else"""

MY_NUM = 100
for current_number in range(15):
    if current_number == MY_NUM:
        print("Found!")
        break
else:
    print("Nothing here...")

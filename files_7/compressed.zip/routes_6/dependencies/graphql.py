print("I'm graphql dependency")

def init(graphql, **_):
    print(f"I'm module one: {graphql}")

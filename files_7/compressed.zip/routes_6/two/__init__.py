def init(db, api, **_):
    print(f"I'm module two: {db}, {api}")

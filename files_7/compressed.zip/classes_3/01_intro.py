message = "hello world!"
print(type(message))

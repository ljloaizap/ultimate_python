from users.taxes.utils import pay_taxes
# import users

pay_taxes()
# print(__name__)

# print(users.management.__name__)
# print(users.taxes.__package__)
# print(users.management.__path__)
# print(users.taxes.__file__)
